using UnityEngine;

public enum ElementType {
    Iron,
    Nickel,
    Si
}

public class ElementIdentifier : MonoBehaviour {
    public ElementType elementType;
}
