using UnityEngine;
using UnityEngine.EventSystems;

public class Drag_Iron : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    public string elementName; // Iron, Nickel, Silicates

    private GameManagerScript gameManager;
    private Transform rectTransform;
    private Canvas canvas;
    private Vector3 originalPosition;

    void Start() {
        rectTransform = GetComponent<Transform>();
        canvas = Object.FindFirstObjectByType<Canvas>();  // Updated method
        gameManager = Object.FindFirstObjectByType<GameManagerScript>();  // Updated method
        originalPosition = rectTransform.position;  // Save the original position
    }

    public void OnBeginDrag(PointerEventData eventData){
        Debug.Log("Drag started: " + gameObject.name);
    }

    public void OnDrag(PointerEventData eventData) {
        rectTransform.position += new Vector3(eventData.delta.x, eventData.delta.y, 0) / canvas.scaleFactor;
    }
    public void OnEndDrag(PointerEventData eventData) {
        if (IsCorrectTarget(eventData)) {
                Debug.Log("Correct Match!");
                Destroy(gameObject);  // Remove the matched element
                gameManager.UpdateProgress(true);
        } else {
            Debug.Log("Incorrect Match@@!");
            rectTransform.position = originalPosition;  // Reset position
            gameManager.UpdateProgress(false);
        }
    }

/*
    private bool IsCorrectTarget(PointerEventData eventData) {
        GameObject hoveredObject = eventData.pointerCurrentRaycast.gameObject;

        if (hoveredObject != null && hoveredObject.CompareTag("DropArea")) {
            string expectedElement = Object.FindFirstObjectByType<DropElements>().GetExpectedElement(hoveredObject);
            // Debugging log
        Debug.Log("Dragged Object: " + elementName);
        Debug.Log("Expected Object: " + expectedElement);
            return expectedElement == elementName; 
            //return true;
        }
        return false;
    }*/
    private bool IsCorrectTarget(PointerEventData eventData) {
    GameObject hoveredObject = eventData.pointerCurrentRaycast.gameObject;

    if (hoveredObject == null) {
        Debug.Log("Hovered object is null. Nothing was under the pointer.");
    } else {
        Debug.Log("Hovered Object Name: " + hoveredObject.name);
    }

    if (hoveredObject != null && hoveredObject.CompareTag("DropArea")) {
        string expectedElement = Object.FindFirstObjectByType<DropElements>().GetExpectedElement(hoveredObject);

        // Debugging log
        Debug.Log("Dragged Object: " + elementName);
        Debug.Log("Expected Object: " + expectedElement);

        return expectedElement == elementName; 
    }
    
    Debug.Log("IsCorrectTarget failed: No valid DropArea or mismatched tag.");
    return false;
    }

}
