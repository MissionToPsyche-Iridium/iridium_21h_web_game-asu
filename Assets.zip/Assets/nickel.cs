using UnityEngine;
using UnityEngine.EventSystems;

public class NickelScript : MonoBehaviour, IDragHandler, IEndDragHandler
{
    public string elementName; // Iron, Nickel, Silicates
    private GameManagerScript gameManager;

    private Transform rectTransform;
    private Canvas canvas;
    private Vector3 originalPosition;

    void Start()
    {
        rectTransform = GetComponent<Transform>();
        canvas = Object.FindFirstObjectByType<Canvas>();  // Updated method
        gameManager = Object.FindFirstObjectByType<GameManagerScript>();  // Updated method
        originalPosition = rectTransform.position;  // Save the original position
    }

    public void OnDrag(PointerEventData eventData)
    {
        rectTransform.position += new Vector3(eventData.delta.x, eventData.delta.y, 0) / canvas.scaleFactor;
    }
    public void OnEndDrag(PointerEventData eventData)
    {
        if (IsCorrectTarget(eventData))
        {
            Debug.Log("Correct Match!");
            Destroy(gameObject);  // Remove the matched element
            gameManager.UpdateProgress(true);
        }
        else
        {
            Debug.Log("Incorrect Match!");
            rectTransform.position = originalPosition;  // Reset position
            gameManager.UpdateProgress(false);
        }
    }


    private bool IsMatch()
    {
        if (elementName == "Iron") {
            gameManager.UpdateProgress(true);
        }
        return true; // Placeholder
    }

    private bool IsCorrectTarget(PointerEventData eventData)
    {
        GameObject hoveredObject = eventData.pointerCurrentRaycast.gameObject;

        if (hoveredObject != null && hoveredObject.CompareTag("DropArea"))
        {
            return true;
        }

        return false;
    }
}
