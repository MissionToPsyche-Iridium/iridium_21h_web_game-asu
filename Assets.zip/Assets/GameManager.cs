using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameManagerScript : MonoBehaviour
{
    public TMP_Text timerText;
    public float gameTime = 120f; // 1 minutes
    public Slider greenBar;
    public GameObject Success;
    public GameObject Fail;
    public GameObject BackGroundImage;

    private float currentProgress = 0f;
    private bool gameActive = true;
    
    void Start() {
        int minutes = Mathf.FloorToInt(gameTime / 60); // Get the minutes
        int seconds = Mathf.FloorToInt(gameTime % 60); // Get the remaining seconds
        timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
        Success.SetActive(false);
        Fail.SetActive(false);
    }

    void Update() {
        if (gameActive) {
            gameTime -= Time.deltaTime;
            int minutes = Mathf.FloorToInt(gameTime / 60); // Get minutes
            int seconds = Mathf.FloorToInt(gameTime % 60); // Get seconds

            // Format the timer as MM:SS
            timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);

            if (gameTime <= 0) {
                FailGame();
            }
        }
    }

    public void UpdateProgress(bool correct) {
        if (correct) {
            currentProgress += 0.05f;
            greenBar.value = currentProgress;
            if (currentProgress >= 1f){
                WinGame();
            }
        } else {
            Debug.Log("Wrong Element!");
            greenBar.value = currentProgress;
        }
    }

    void WinGame() {
        gameActive = false;
        Success.SetActive(true);
        Debug.Log("Congratulation!");
    }

    void FailGame() {
        gameActive = false;
        Fail.SetActive(true);
        Debug.Log("Game Over!");
    }
}
