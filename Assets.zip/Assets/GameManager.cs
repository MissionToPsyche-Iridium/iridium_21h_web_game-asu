using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    [Header("UI References")]
    public TMP_Text timerText;
    public Slider greenBar;
    public GameObject successUI; 
    public GameObject failUI;

    [Header("Buttons (Before Game)")]
    public Button startButton;

    [Header("Buttons (During Game)")]
    public Button pauseButton;
    public TMP_Text pauseButtonText;  // New: reference to the Pause button's text
    public Button manualButton;
    public Button duringGameMenuButton; // 'Main Menu' displayed during game

    [Header("Buttons (After Game)")]
    public Button restartButton;
    public Button afterGameMenuButton; // 'Main Menu' displayed after game

    [Header("Game Settings")]
    public float totalTime = 30f;
    private float currentTime;
    private float currentProgress = 0f;

    private bool gameActive = false;
    private bool isPaused = false;

    void Start() {
        if (successUI) successUI.SetActive(false);
        if (failUI) failUI.SetActive(false);

        // Initially, show only the Start button
        if (startButton) startButton.gameObject.SetActive(true);

        // Hide during-game buttons
        if (pauseButton) pauseButton.gameObject.SetActive(false);
        if (manualButton) manualButton.gameObject.SetActive(false);
        if (duringGameMenuButton) duringGameMenuButton.gameObject.SetActive(false);

        // Hide after-game buttons
        if (restartButton) restartButton.gameObject.SetActive(false);
        if (afterGameMenuButton) afterGameMenuButton.gameObject.SetActive(false);

        currentTime = totalTime;
        UpdateTimerDisplay();
    }

    void Update() {
        if (gameActive && !isPaused) {
            currentTime -= Time.deltaTime;
            if (currentTime <= 0f) {
                currentTime = 0f;
                FailGame();
            }
            UpdateTimerDisplay();
        }
    }

    public void UpdateProgress(bool correct) {
        if (!gameActive) return;

        if (correct) {
            currentProgress += 0.05f;
            if (greenBar) greenBar.value = currentProgress;
            if (currentProgress >= 1f) {
                WinGame();
            }
        } else {
            Debug.Log("Wrong Element!");
            if (greenBar) greenBar.value = currentProgress;
        }
    }

    void WinGame() {
        gameActive = false;
        if (successUI) successUI.SetActive(true);

        // Hide during-game buttons
        if (pauseButton) pauseButton.gameObject.SetActive(false);
        if (manualButton) manualButton.gameObject.SetActive(false);
        if (duringGameMenuButton) duringGameMenuButton.gameObject.SetActive(false);

        // Show after-game buttons
        if (restartButton) restartButton.gameObject.SetActive(true);
        if (afterGameMenuButton) afterGameMenuButton.gameObject.SetActive(true);

        Debug.Log("You Win!");
    }

    void FailGame() {
        gameActive = false;
        if (failUI) failUI.SetActive(true);

        // Hide during-game buttons
        if (pauseButton) pauseButton.gameObject.SetActive(false);
        if (manualButton) manualButton.gameObject.SetActive(false);
        if (duringGameMenuButton) duringGameMenuButton.gameObject.SetActive(false);

        // Show after-game buttons
        if (restartButton) restartButton.gameObject.SetActive(true);
        if (afterGameMenuButton) afterGameMenuButton.gameObject.SetActive(true);

        Debug.Log("Game Over!");
    }

    // ====== BUTTON METHODS ======

    public void OnStartGame() {
        Debug.Log("OnStartGame() called.");
        if (startButton) startButton.gameObject.SetActive(false);

        // Show during-game buttons
        if (pauseButton) pauseButton.gameObject.SetActive(true);
        if (manualButton) manualButton.gameObject.SetActive(true);
        if (duringGameMenuButton) duringGameMenuButton.gameObject.SetActive(true);

        // Reset
        gameActive = true;
        isPaused = false;
        currentTime = totalTime;
        currentProgress = 0f;
        if (greenBar) greenBar.value = 0f;
        if (successUI) successUI.SetActive(false);
        if (failUI) failUI.SetActive(false);

        // Set pause button text to "Pause" initially
        if (pauseButtonText) pauseButtonText.text = "Pause";

        Debug.Log("Game Started!");
    }

    // Toggle play/pause with one button
    public void OnTogglePause() {
        isPaused = !isPaused;
        if (isPaused) {
            Time.timeScale = 0f;
            if (pauseButtonText) pauseButtonText.text = "Play";
            Debug.Log("Game Paused");
        } else {
            Time.timeScale = 1f;
            if (pauseButtonText) pauseButtonText.text = "Pause";
            Debug.Log("Game Resumed");
        }
    }

    public void OnShowManual() {
        Debug.Log("Manual...");
    }

    public void OnMainMenuButton() {
        Debug.Log("Go to Main Menu");
    }

    public void OnRestartGame() {
        Time.timeScale = 1f;
        // manually reset everything
        gameActive = false;
        isPaused = false;
        currentTime = totalTime;
        currentProgress = 0f;
        if (greenBar) greenBar.value = 0f;
        if (successUI) successUI.SetActive(false);
        if (failUI) failUI.SetActive(false);

        // Hide after-game buttons
        if (restartButton) restartButton.gameObject.SetActive(false);
        if (afterGameMenuButton) afterGameMenuButton.gameObject.SetActive(false);

        // Show during-game buttons
        if (pauseButton) pauseButton.gameObject.SetActive(true);
        if (manualButton) manualButton.gameObject.SetActive(true);
        if (duringGameMenuButton) duringGameMenuButton.gameObject.SetActive(true);

        gameActive = true;
        UpdateTimerDisplay();

        Debug.Log("Game Restarted!");
    }

    void UpdateTimerDisplay() {
        if (!timerText) return;
        int minutes = Mathf.FloorToInt(currentTime / 60);
        int seconds = Mathf.FloorToInt(currentTime % 60);
        timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);
    }
}
