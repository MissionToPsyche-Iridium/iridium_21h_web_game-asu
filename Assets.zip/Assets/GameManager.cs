using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    public TMP_Text timerText;
    public float gameTime = 30f; // 30 seconds
    public Slider greenBar;
    public GameObject Success;
    public GameObject Fail;
    public GameObject BackGroundImage;

    private float currentProgress = 0f;
    private bool gameActive = true;
    
    void Start() {
        Success.SetActive(false);
        Fail.SetActive(false);
    }

    void Update() {
    if (gameActive) {
        gameTime -= Time.deltaTime;

        gameTime = Mathf.Max(0, gameTime);

        int minutes = Mathf.FloorToInt(gameTime / 60);
        int seconds = Mathf.FloorToInt(gameTime % 60);

        timerText.text = string.Format("{0:00}:{1:00}", Mathf.Max(0, minutes), Mathf.Max(0, seconds));

        if (gameTime <= 0) {
            gameActive = false; // Stop the timer
            timerText.text = "00:00"; // Force display 00:00
            FailGame();
        }
    }
}

    public void UpdateProgress(bool correct) {
        if (correct) {
            currentProgress += 0.05f;
            greenBar.value = currentProgress;
            if (currentProgress >= 1f){
                WinGame();
            }
        } else {
            Debug.Log("Wrong Element!");
            greenBar.value = currentProgress;
        }
    }

    void WinGame() {
        gameActive = false;
        Success.SetActive(true);
        Debug.Log("Congratulation!");
    }

    void FailGame() {
        gameActive = false;
        Fail.SetActive(true);
        Debug.Log("Game Over!");
    }

    void instruct(){
        gameActive = true;
        Debug.Log("Do you know how to play this game?");
    }
}
