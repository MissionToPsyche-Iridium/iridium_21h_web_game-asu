using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;

public class DropElements : MonoBehaviour {
    public GameObject[] elementPrefabs; // Prefabs of Iron, Nickel, Silicates
    public GameObject[] dropAreas;      // Drop Areas

    private Dictionary<GameObject, string> expectedElements = new Dictionary<GameObject, string>();
    void Start() {
        AssignRandomElements();
    }

    void AssignRandomElements() {
        for (int i = 0; i < dropAreas.Length; i++) {
        int randomIndex = Random.Range(0, elementPrefabs.Length);
        Image elementImage = dropAreas[i].GetComponent<Image>();

            if (elementImage != null) {
                Image prefabImage = elementPrefabs[randomIndex].GetComponent<Image>(); 
                if (prefabImage != null) {
                    elementImage.sprite = prefabImage.sprite; 
                    expectedElements[dropAreas[i]] = elementPrefabs[randomIndex].name; 
                } else {
                    Debug.LogError("Prefab missing Image component: " + elementPrefabs[randomIndex].name);
                }
            }
        }
    }

    public void OnDrop(PointerEventData eventData, GameObject dropArea) {
        GameObject draggedObject = eventData.pointerDrag;

        if (draggedObject != null && expectedElements.ContainsKey(dropArea)) {
            string draggedName = draggedObject.name.Replace("(Clone)", "").Trim();

        Debug.Log("Dragged Element: " + draggedName);
        Debug.Log("Expected Element: " + expectedElements[dropArea]);
            if (draggedObject.name == expectedElements[dropArea]) {
                Debug.Log("Correct Match!");
                Destroy(draggedObject); // Correct match
                Object.FindFirstObjectByType<GameManagerScript>().UpdateProgress(true);
            } else {
                Debug.Log("Incorrect Match!");
                Object.FindFirstObjectByType<GameManagerScript>().UpdateProgress(false);
            }
        }
    }


    public string GetExpectedElement(GameObject dropArea) {
        if (expectedElements.ContainsKey(dropArea)) {
            return expectedElements[dropArea];
        }
        return null; // No expected element found
    }
}


