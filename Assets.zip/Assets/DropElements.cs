using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;

public class DropElements : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    public GameObject[] elementPrefabs;
    public GameObject[] DropArea;

    private Dictionary<GameObject, ElementType> expectedElements = new Dictionary<GameObject, ElementType>();

    private GameObject currentDraggedObject;
    private Vector3 originalPosition;

    void Start() {
        AssignRandomElements();
    }

    void AssignRandomElements() {
        expectedElements.Clear();
        Debug.Log("------ Assigning Random Elements ------");

        for (int i = 0; i < DropArea.Length; i++) {
            int randomIndex = Random.Range(0, elementPrefabs.Length);
            GameObject selectedPrefab = elementPrefabs[randomIndex];
            Image dropAreaImage = DropArea[i].GetComponent<Image>();
            Image prefabImage = selectedPrefab.GetComponent<Image>();
            ElementIdentifier prefabID = selectedPrefab.GetComponent<ElementIdentifier>();

            if (dropAreaImage == null || prefabImage == null || prefabID == null) {
                Debug.LogError("Missing components on DropArea or Prefab: " + DropArea[i].name + " / " + selectedPrefab.name);
                continue;
            }

            dropAreaImage.sprite = prefabImage.sprite;
            expectedElements[DropArea[i]] = prefabID.elementType;

            Debug.Log("[AssignRandomElements] Assigned " + prefabID.elementType + " (Sprite: " + dropAreaImage.sprite.name + ") to " + DropArea[i].name);
        }

        Debug.Log("------ Expected Elements Dictionary ------");
        foreach (var pair in expectedElements) {
            Debug.Log(pair.Key.name + " expects: " + pair.Value);
        }
    }

    // =========== DRAG HANDLERS ===========

    public void OnBeginDrag(PointerEventData eventData) {
        currentDraggedObject = eventData.pointerDrag;
        if (currentDraggedObject != null) {
            originalPosition = currentDraggedObject.transform.position;

            Image imageComponent = currentDraggedObject.GetComponent<Image>();
            if (imageComponent != null) {
                imageComponent.raycastTarget = false;
            }
        }
    }

    public void OnDrag(PointerEventData eventData) {
        if (currentDraggedObject != null) {
            float scaleFactor = FindFirstObjectByType<Canvas>().scaleFactor;
            currentDraggedObject.transform.position += new Vector3(eventData.delta.x, eventData.delta.y, 0) / scaleFactor;
        }
    }

    public void OnEndDrag(PointerEventData eventData) {
        if (currentDraggedObject != null) {
            Image imageComponent = currentDraggedObject.GetComponent<Image>();
            if (imageComponent != null) {
                imageComponent.raycastTarget = true;
            }
            
            currentDraggedObject.transform.position = originalPosition;
            currentDraggedObject = null;
        }
    }

    // =========== DROP HANDLER ===========

    public void HandleDrop(GameObject userElement, GameObject dropAreaObj) {
        if (userElement == null || dropAreaObj == null) return;
            ElementIdentifier userID = userElement.GetComponent<ElementIdentifier>();

        if (userID == null) {
            Debug.LogError("Dragged element missing ElementIdentifier!");
            userElement.transform.position = originalPosition;
            return;
        }

        // Check the dictionary for the expected element
        if (!expectedElements.ContainsKey(dropAreaObj)) {
            Debug.LogError("Drop area " + dropAreaObj.name + " not found in dictionary!");
            userElement.transform.position = originalPosition;
            return;
        }

        ElementType draggedType = userID.elementType;
        ElementType expectedType = expectedElements[dropAreaObj];

        Debug.Log("Dropped Element: " + draggedType + ", Expected: " + expectedType);

        // Compare the types
        if (draggedType == expectedType) {
            Debug.Log("[HandleDrop] Correct Match!");
            ReplaceMatchedElement(dropAreaObj);
            Object.FindFirstObjectByType<GameManager>().UpdateProgress(true);
        } else {
            Debug.Log("[HandleDrop] Incorrect Match! Resetting position.");
            userElement.transform.position = originalPosition;
            Object.FindFirstObjectByType<GameManager>().UpdateProgress(false);
        }
    }

    // Called if the user matched correctly
    void ReplaceMatchedElement(GameObject dropAreaObj) {
        if (dropAreaObj == null) return;

        Image dropAreaImage = dropAreaObj.GetComponent<Image>();
        if (dropAreaImage == null) {
            Debug.LogError(dropAreaObj.name + " is missing an Image component!");
            return;
        }

        GameObject selectedPrefab;
        string currentSpriteName = dropAreaImage.sprite.name;

        do {
            int randomIndex = Random.Range(0, elementPrefabs.Length);
            selectedPrefab = elementPrefabs[randomIndex];
        } while (selectedPrefab.GetComponent<Image>().sprite.name == currentSpriteName);

        // Assign the new sprite
        dropAreaImage.sprite = selectedPrefab.GetComponent<Image>().sprite;

        // Update the dictionary with the new element type
        ElementIdentifier newID = selectedPrefab.GetComponent<ElementIdentifier>();
        if (newID == null) {
            Debug.LogError("Selected prefab missing ElementIdentifier!");
            return;
        }

        expectedElements[dropAreaObj] = newID.elementType;

        Debug.Log("[ReplaceMatchedElement] New element assigned to " + dropAreaObj.name + ": " + newID.elementType + " (Sprite: " + dropAreaImage.sprite.name + ")");
    }
}
