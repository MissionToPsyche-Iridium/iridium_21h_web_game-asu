using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;

public class DropElements : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler {
    public GameObject[] elementPrefabs;
    public GameObject[] DropArea;

    private Dictionary<GameObject, string> expectedElements = new Dictionary<GameObject, string>();
    private GameObject currentDraggedObject;
    private Vector3 originalPosition;

    void Start() {
        AssignRandomElements();
    }

    void AssignRandomElements() {
        if (DropArea == null || DropArea.Length == 0) {
            Debug.LogError("DropAreas array is empty! Assign them in the Inspector.");
            return;
        }
        if (elementPrefabs == null || elementPrefabs.Length == 0) {
            Debug.LogError("ElementPrefabs array is empty! Assign them in the Inspector.");
            return;
        }

        expectedElements.Clear();

        Debug.Log("------ Assigning Random Elements ------");
        for (int i = 0; i < DropArea.Length; i++) {
            int randomIndex = Random.Range(0, elementPrefabs.Length);
            GameObject selectedPrefab = elementPrefabs[randomIndex];

            Image elementImage = DropArea[i].GetComponent<Image>();
            if (elementImage == null) {
                Debug.LogError($"DropArea {DropArea[i].name} is missing an Image component!");
                continue;
            }

            Image prefabImage = selectedPrefab.GetComponent<Image>();
            if (prefabImage == null) {
                Debug.LogError("Prefab missing Image component: " + selectedPrefab.name);
                continue;
            }

            // Assign the sprite from the selected prefab
            elementImage.sprite = prefabImage.sprite;

            // Store the **actual prefab name** in the dictionary
            string assignedName = selectedPrefab.name.Trim();
            expectedElements[DropArea[i]] = assignedName;

            Debug.Log($"Assigned {assignedName} (Sprite: {elementImage.sprite.name}) to {DropArea[i].name}");
        }

        Debug.Log("------ Expected Elements Dictionary ------");
        foreach (var pair in expectedElements) {
            Debug.Log($"DropArea {pair.Key.name} expects: {pair.Value}");
        }
    }

    public void OnBeginDrag(PointerEventData eventData) {
        currentDraggedObject = eventData.pointerDrag;
        if (currentDraggedObject != null) {
            originalPosition = currentDraggedObject.transform.position;

            Image imageComponent = currentDraggedObject.GetComponent<Image>();
            if (imageComponent != null) {
                imageComponent.raycastTarget = false;
            }
        }
    }

    public void OnDrag(PointerEventData eventData) {
        if (currentDraggedObject != null) {
            currentDraggedObject.transform.position += new Vector3(eventData.delta.x, eventData.delta.y, 0) / FindFirstObjectByType<Canvas>().scaleFactor;
        }
    }

    public void OnEndDrag(PointerEventData eventData) {
        if (currentDraggedObject != null) {
            Image imageComponent = currentDraggedObject.GetComponent<Image>();
            if (imageComponent != null) {
                imageComponent.raycastTarget = true;
            }

            GameObject hoveredObject = eventData.pointerCurrentRaycast.gameObject;

            if (hoveredObject == null) {
                currentDraggedObject.transform.position = originalPosition;
                return;
            }

            while (hoveredObject != null && !hoveredObject.CompareTag("DropArea")) {
                hoveredObject = hoveredObject.transform.parent?.gameObject;
            }

            if (hoveredObject == null) {
                currentDraggedObject.transform.position = originalPosition;
                return;
            }

            string draggedName = currentDraggedObject.name.Replace("(Clone)", "").Trim();
            string expectedName = GetExpectedElement(hoveredObject)?.Replace("(Clone)", "").Trim();

            if (expectedName == null) {
                currentDraggedObject.transform.position = originalPosition;
                return;
            }

            if (draggedName == expectedName) {
                HandleDrop(currentDraggedObject, hoveredObject);
            } else {
                currentDraggedObject.transform.position = originalPosition;
                Object.FindFirstObjectByType<GameManager>().UpdateProgress(false);
            }
        }
    }

    public string GetExpectedElement(GameObject DropArea) {
        if (expectedElements.ContainsKey(DropArea)) {
            string expectedName = expectedElements[DropArea];
            Debug.Log($"DropArea {DropArea.name} expects: {expectedName}");
            return expectedName;
        }
        Debug.LogError($"DropArea {DropArea.name} is missing from dictionary!");
        return null;
    }

    public void HandleDrop(GameObject userElement, GameObject DropArea) {
        if (userElement == null || DropArea == null) return;

        string draggedName = userElement.name.Replace("(Clone)", "").Trim();
        string expectedName = GetExpectedElement(DropArea)?.Replace("(Clone)", "").Trim();
        Image dropAreaImage = DropArea.GetComponent<Image>();
        Image userElementImage = userElement.GetComponent<Image>();

        Debug.Log($"🔍 Dropped Element: {draggedName} (Sprite: {userElementImage.sprite.name}), " + 
                $"Expected: {expectedName} (DropArea {DropArea.name} Sprite: {dropAreaImage.sprite.name})");

        if (expectedName == null) {
            Debug.LogError($"No expected element found for DropArea: {DropArea.name}");
            return;
        }

        if (draggedName == expectedName && userElementImage.sprite.name == dropAreaImage.sprite.name) {
            Debug.Log("Correct Match! Updating element...");
            ReplaceMatchedElement(DropArea);
            userElement.transform.position = originalPosition;
            Object.FindFirstObjectByType<GameManager>().UpdateProgress(true);
        } else {
            Debug.Log($"Incorrect Match! Dragged {draggedName}, Expected {expectedName}");
            userElement.transform.position = originalPosition; 
            Object.FindFirstObjectByType<GameManager>().UpdateProgress(false);
        }
    }


    void ReplaceMatchedElement(GameObject DropArea) {
        if (DropArea == null) return;

        int randomIndex = Random.Range(0, elementPrefabs.Length);
        Image dropAreaImage = DropArea.GetComponent<Image>();

        if (dropAreaImage != null) {
            dropAreaImage.sprite = elementPrefabs[randomIndex].GetComponent<Image>().sprite;
            expectedElements[DropArea] = elementPrefabs[randomIndex].name;
            Debug.Log($"New element assigned to {DropArea.name}: {expectedElements[DropArea]}");
        } else {
            Debug.LogError($"Failed to replace element in {DropArea.name}");
        }
    }

}
